#define CATCH_CONFIG_MAIN
#include <iostream>
#include <pprint.hpp>
// STL Containers
#include <test_vector.hpp>
#include <test_list.hpp>
#include <test_set.hpp>
